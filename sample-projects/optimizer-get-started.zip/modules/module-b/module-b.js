raptor.define(
    "module-b",
    function(raptor) {
        return {
            hello: function() {
                return 'Hello from "module-b"!';
            }
        };
    });
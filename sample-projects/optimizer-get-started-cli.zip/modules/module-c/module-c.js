define(
    "module-c",
    function(require) {
        return {
            hello: function() {
                return 'Hello from "module-c"!';
            }
        };
    });
define(
    "module-c",
    function(raptor) {
        return {
            hello: function() {
                return 'Hello from "module-c"!';
            }
        };
    });
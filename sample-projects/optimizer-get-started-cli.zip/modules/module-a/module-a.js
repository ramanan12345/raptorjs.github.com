define(
    "module-a",
    function(raptor) {
        return {
            sayHello: function() {
                alert('Hello from "module-a"!');
            }
        };
    });
(function() {
    require('module-a').sayHello();
}());
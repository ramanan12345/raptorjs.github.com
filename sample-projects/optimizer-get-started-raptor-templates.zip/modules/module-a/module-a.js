define(
    "module-a",
    function(raptor) {
        return {
            hello: function() {
                return 'Hello from "module-a"!';
            }
        };
    });
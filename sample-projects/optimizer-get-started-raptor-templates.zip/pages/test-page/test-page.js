define(
    'test-page',
    function() {
        return {
            init: function() {
                //Do something on page init...
            }
        }
    });